#define TINYOBJLOADER_IMPLEMENTATION
#include "../Externals/Include/TinyOBJ/tiny_obj_loader.h"
#define STB_IMAGE_IMPLEMENTATION
#include "../Externals/Include/STB/stb_image.h"
#define GLUTILS_IMPLEMENTATION
#include "../Externals/Include/utils/glutils.hpp"
#define TIMER_IMPLEMENTATION
#include "../Externals/Include/utils/timer.hpp"
